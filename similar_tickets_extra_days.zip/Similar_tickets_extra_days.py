import pandas as pd
import numpy as np
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize 
from nltk.stem.porter import PorterStemmer
stemmer = PorterStemmer()

open_ticket_count = 10
extract_similar_tickets = 10

Data = pd.read_excel("Case Data Dump from Jan'21 to Jul'21.xlsx")
input_config = pd.read_csv('Input_similar_tickets.csv')


#Merging Description and Subject for similarity check
# sophos['merged'] = sophos['Description'].astype(str) + " " + sophos['Subject'].astype(str)
# print("Total tickets found:", len(sophos))

#Selection of Closed tickets into DataFrame
# sophos_input = pd.read_excel("Cases_open_input.xlsx")
sophos_input = Data[Data['Product'] == input_config['Value'][0]]
sophos_input = sophos_input[sophos_input['Category'] == input_config['Value'][1]]
sophos_input = sophos_input[sophos_input['Priority'] == input_config['Value'][2]]
sophos = sophos_input[sophos_input['Priority'] == input_config['Value'][2]]

# print(len(sophos_input))
# sophos_open = sophos_input[sophos_input['Case Record Type'] != 'Closed_Case_Record_Type']
# sophos_open = sophos_open.drop_duplicates(['Case Number'], keep='last')
# print("Total unique open tickets found:", len(sophos_open))

#Selection of Open tickets into DataFrame
sophos_close = sophos[sophos['Case Record Type'] == 'Closed_Case_Record_Type']
sophos_close = sophos_close.drop_duplicates(['Case Number'], keep='last')
print("Total unique closed tickets found:", len(sophos_close))

sophos_open = sophos_close.drop_duplicates(['Case Number'], keep='last')

#Cleaning open tickets
sophos_desc_o = sophos_open['Subject'].tolist()
sophos_desc_o_clean = []
for i in sophos_desc_o:
    if i == '':
        sophos_desc_o_clean.append(' ')
        break
    if type(i) != float and type(i) != int:
        sophos_desc_o_clean.append(i.replace('\n', ' ').replace('\r', ' ').replace('\\', ' ').replace('nan', ' '))
    else:
        sophos_desc_o_clean.append(' ')        
                    
Case_Number_o = sophos_open['Case Number'].tolist()
Status_o = sophos_open['Case Record Type'].tolist()
Sbj_o = sophos_open['Case Age(Since Opened)'].tolist()
Product_Category_o = sophos_open['Product'].tolist()

#Looping through each open ticket
similar_tickets = pd.DataFrame()
if len(sophos_open) > 0:
    clustered_desc = []
    count = 0
    for ii,X in enumerate(sophos_desc_o_clean[:len(sophos_open)]):
        if Case_Number_o[ii] not in clustered_desc:
            count = count+1
            print(f'Checking #{ii+1}/{len(sophos_open)}:', Case_Number_o[ii])
#         try:        
#             Filtering based on Product_Category
            if type(Product_Category_o[ii]) is str:
                sophos_c = sophos_close[sophos_close['Product'] == Product_Category_o[ii]]  
            else:
                sophos_c = sophos_close
            
            #print("Product Category:", Product_Category_o[ii])
            #print("Subject:", Sbj_o[ii])
            #print('Number of tickets with matching product category:', len(sophos_c))
                                
            Case_Number_cc = sophos_c['Case Number'].tolist()
            sophos_desc_cc = sophos_c['Subject'].tolist()
            Sbj_cc = sophos_c['Case Age(Since Opened)'].tolist()
            Date_closed_cc = sophos_c['Date/Time Opened'].tolist()
            Case_Owner_cc = sophos_c['Case Owner: Full Name'].tolist()
            
            Case_Number_c, sophos_desc_c, Sbj_c, Date_closed_c, Case_Owner_c, Cluster = [], [], [], [], [], []
            for i,val in enumerate(Case_Number_cc):
                if val not in clustered_desc:
                    Case_Number_c.append(sophos_c['Case Number'].tolist()[i])
                    sophos_desc_c.append(sophos_c['Subject'].tolist()[i])
                    Sbj_c.append(sophos_c['Case Age(Since Opened)'].tolist()[i])
                    Date_closed_c.append(sophos_c['Date/Time Opened'].tolist()[i])
                    Case_Owner_c.append(sophos_c['Case Owner: Full Name'].tolist()[i])
                    Cluster.append(count)
            print(len(clustered_desc), len(sophos_desc_c))    
            
                
            sophos_desc_c_clean = []    
            for i in sophos_desc_c:
                if i == '':
                    sophos_desc_c_clean.append(' ')
                    break
                if type(i) != float and type(i) != int:
                    sophos_desc_c_clean.append(i.replace('\n', ' ').replace('-', ' ').replace('\r', ' ').replace('\\', ' ').replace('nan', ' '))
                else:
                    sophos_desc_c_clean.append(' ')

            #Looping through each closed ticket
            similarity_index = []
            for j,Y in enumerate(sophos_desc_c_clean):
#                 print(X,'----' ,Y)
                if Y != ' ':
                    #Removing symbols
                    symbols = "!\"#$%&()*+-./:;<=>?@[\]^_`{|}~\n"
                    for i in symbols:
                        Y = Y.replace(i, ' ')
                        X = X.replace(i, ' ')

                    X_list = word_tokenize(X.lower())  
                    Y_list = word_tokenize(Y.lower()) 

                    # sw contains the list of stopwords 
                    sw = stopwords.words('english')  
                    l1 =[];l2 =[] 

                    # remove stop words from the string 
                    X_set = {w for w in X_list if not w in sw}  
                    Y_set = {w for w in Y_list if not w in sw} 

                    #Stemming and remove words with length 1 and 2 letters
                    X_set_new, Y_set_new = {''}, {''}
                    for w in X_set:
                        if len(w) > 2:
                            X_set_new.add(stemmer.stem(w))
                    for w in Y_set:
                        if len(w) > 2:
                            Y_set_new.add(stemmer.stem(w))    

                    # form a set containing keywords of both strings  
                    rvector = X_set_new.union(Y_set_new)  
                    for w in rvector: 
                        if w in X_set_new: l1.append(1) # create a vector 
                        else: l1.append(0) 
                        if w in Y_set_new: l2.append(1) 
                        else: l2.append(0) 
                    c = 0

                    # cosine formula  
                    for i in range(len(rvector)): 
                            c+= l1[i]*l2[i] 
                    cosine = c / float((sum(l1)*sum(l2))**0.5) 
                    similarity_index.append(round(cosine, 2))
                else:
                    similarity_index.append(0)

            simil_pred = pd.DataFrame({'Sl.no.':ii, 'Open_case': Case_Number_o[ii], 'Open_Ticket_age': Sbj_o[ii], 
                                       "Product Category": Product_Category_o[ii], 'Case_Description': sophos_desc_o[ii],
                                       'Similar_Cases':Case_Number_c, 'Description':sophos_desc_c_clean,
                                       'Closed_Ticket_age': Sbj_c, 'similarity_index' : similarity_index,
                                       'Date_closed': Date_closed_c, 'Case_Owner':Case_Owner_c, 'Cluster': Cluster})
            simil_pred = simil_pred.sort_values(by = 'similarity_index',ascending = False)
            simil_pred = simil_pred.reset_index(inplace = False) 
#             print(simil_pred.head(5))
            
    
            def Extra_days(days):
                ave_days = simil_pred[simil_pred['similarity_index'] > 0.4]['Closed_Ticket_age'].mean()
                return 0 if days < ave_days else days - ave_days

            
            simil_pred['Extra_days'] = simil_pred['Closed_Ticket_age'].apply(Extra_days)

            similar_tickets = similar_tickets.append(simil_pred[simil_pred['similarity_index'] > 0.4])
            for i in simil_pred[simil_pred['similarity_index'] > 0.4]['Similar_Cases'].tolist():
                clustered_desc.append(i)
#         else:
#             print(Case_Number_o[ii])
else:
    print("Sorry, no open tickets found.")
    
similar_tickets =  similar_tickets.drop('index', axis = 1).reset_index().drop('index', axis = 1)
similar_tickets.to_csv('Similar_tickets_output.csv', index = False)